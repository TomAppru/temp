﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Item
    {
        protected int ID;
        protected string itemName;
        protected string itemNamePlural;
        protected string itemDescription;
        protected double cost;

        public Item(int ID, string itemName, string itemNamePlural, string itemDescription, double cost)
        {
            this.ID = ID;
            this.itemName = itemName;
            this.itemNamePlural = itemNamePlural;
            this.itemDescription = itemDescription;
            this.cost = cost;
        }

        public int getID()
        {
            return ID;
        }

        public string getItemName()
        {
            return itemName;
        }

        public string getItemNamePlural()
        {
            return itemNamePlural;
        }

        public string getItemDescription()
        {
            return itemDescription;
        }
    }
}
