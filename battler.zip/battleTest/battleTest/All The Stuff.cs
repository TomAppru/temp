﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    static class All_The_Stuff
    {
        enum enemyType
        {
            Beast,
            Undead,
            Cursed,
            Slime,
            Goblinoid
        };

        public static readonly List<Item> items = new List<Item>();
        public static readonly List<Entity> entities = new List<Entity>();

        public const int ITEM_ID_RUSTY_SWORD = 1;
        public const int ITEM_ID_STEEL_SHORT_SWORD = 2;
        public const int ITEM_ID_WOODEN_CLUB = 3;
        public const int ITEM_ID_IRON_AXE = 4;
        public const int ITEM_ID_BAT_WING = 5;
        public const int ITEM_ID_HANDFUL_OF_FUR = 6;
        public const int ITEM_ID_BLUE_GEM = 7;
        public const int ITEM_ID_WOLFS_PELT = 8;

        public const int ENEMY_ID_RAT = 1;
        public const int ENEMY_ID_BLUE_SLIME = 2;
        public const int ENEMY_ID_ZOMBIE = 3;
        public const int ENEMY_ID_SKELETON = 4;
        public const int ENEMY_ID_BAT = 5;
        public const int ENEMY_ID_WOLF = 6;
        public const int ENEMY_ID_GOBLIN = 7;
        public const int ENEMY_ID_HOB_GOBLIN = 8;
        public const int ENEMY_ID_WEREWOLF = 9;
        public const int ENEMY_ID_WERERAT = 10;

        static All_The_Stuff()
        {
            fillItemList();
            fillEntityList();
        }

        private static void fillItemList()
        {
            items.Add(new Weapon(ITEM_ID_RUSTY_SWORD, "Rusty Sword", "Rusty Swords", "This sword has seen better days, but it'll function.", 2.4, 4, 6));
            items.Add(new Weapon(ITEM_ID_STEEL_SHORT_SWORD, "Steel Short Sword", "Steel Short Swords", "A sturdy sword, shiny and sharp.", 8.15, 6, 11));
            items.Add(new Weapon(ITEM_ID_WOODEN_CLUB, "Wooden Club", "Wooden Clubs", "A heavy piece of wood, ideal skull smasher.", 1.3, 3, 13));
            items.Add(new Weapon(ITEM_ID_IRON_AXE, "Iron Axe", "Iron Axes", "A hefty axe, built for wood, works on bones.", 12.0, 8, 10));
            items.Add(new Item(ITEM_ID_BAT_WING, "Bat Wing", "Bat Wings", "Leathery and kind of gross.", 0.32));
            items.Add(new Item(ITEM_ID_HANDFUL_OF_FUR, "Handful of Fur", "Handfuls of Fur", "There's still a little blood on it.", 0.46));
            items.Add(new Item(ITEM_ID_BLUE_GEM, "Blue Gem", "Blue Gems", "Deep cerulean and shining, worth a lot of gold.", 50.0));
            items.Add(new Item(ITEM_ID_WOLFS_PELT, "Wolf's Pelt", "Wolves' Pelts", "Thick and warm, that wolf howled it's last.", 10));
        }

        private static void fillEntityList()
        {
            Enemy rat = new Enemy(ENEMY_ID_RAT, "Rat", "Rats", "Hungry, the rat skitters to and fro.", 5, 5, enemyType.Beast, 1, 3);
            rat.addToDrops(new Item_Drop(findItem(ITEM_ID_HANDFUL_OF_FUR), 80, 5));
            entities.Add(rat);

            Enemy blueSlime = new Enemy(ENEMY_ID_BLUE_SLIME, "Blue Slime", "Blue Slimes", "The gelatinous sphere wobbles aimlessly.", 4, 4, enemyType.Slime, 2, 3);
            blueSlime.addToDrops(new Item_Drop(findItem(ITEM_ID_BLUE_GEM), 5, 2));
            entities.Add(blueSlime);

            Enemy zombie = new Enemy(ENEMY_ID_ZOMBIE, "Zombie", "Zombies", "Braindead, the zombie groans as it shambles forwards.", 7, 7, enemyType.Undead, 7, 10);
            zombie.addToDrops(new Item_Drop(findItem(ITEM_ID_WOODEN_CLUB), 20, 1));
            entities.Add(zombie);

            Enemy skeleton = new Enemy(ENEMY_ID_SKELETON, "Skeleton", "Skeletons", "The loose bones rattle as empty eye sockets stare at you, angrily.", 6, 6, enemyType.Undead, 5, 9);
            skeleton.addToDrops(new Item_Drop(findItem(ITEM_ID_RUSTY_SWORD), 20, 1));
            entities.Add(skeleton);

            Enemy bat = new Enemy(ENEMY_ID_BAT, "Bat", "Bats", "The bat darts around, screeching.", 3, 3, enemyType.Beast, 2, 3);
            bat.addToDrops(new Item_Drop(findItem(ITEM_ID_BAT_WING), 75, 2));
            entities.Add(bat);

            Enemy wolf = new Enemy(ENEMY_ID_WOLF, "Wolf", "Wolves", "The wolf keeps its head low and snarls, waiting.", 10, 10, enemyType.Beast, 9, 12);
            wolf.addToDrops(ne)

        }

        private static Item findItem(int ID)
        {
            foreach(Item i in items)
            {
                if (i.getID() == ID)
                {
                    return i;
                }
            }

            return null;
        }
    }
}
