﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Weapon : Item
    {
        private int minDamage;
        private int maxDamage;

        public Weapon(int ID, string itemName, string namePlural, string itemDescription, double cost, int minDamage, int maxDamage) :
            base(ID, itemName, namePlural, itemDescription, cost)
        {
            this.minDamage = minDamage;
            this.maxDamage = maxDamage;
        }

        public int getMinDamage()
        {
            return minDamage;
        }

        public int getMaxDamage()
        {
            return maxDamage;
        }
    }
}
