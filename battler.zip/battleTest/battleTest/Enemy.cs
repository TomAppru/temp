﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Enemy : Entity
    {
        private int ID;
        private string name;
        private string namePlural;
        private string description;
        private Enum type;
        private int minDamage;
        private int maxDamage;
        private List<Item_Drop> loot;

        public Enemy(int ID, string name, string namePlural, string description, int maxHP, int currentHP, Enum type, int minDamage, int maxDamage) : 
            base(maxHP, currentHP)
        {
            this.ID = ID;
            this.name = name;
            this.namePlural = namePlural;
            this.description = description;
            this.type = type;
            this.minDamage = minDamage;
            this.maxDamage = maxDamage;
            loot = new List<Item_Drop>();
        }

        public Enum getType()
        {
            return type;
        }

        public int getMinDamage()
        {
            return minDamage;
        }

        public int getMaxDamage()
        {
            return maxDamage;
        }

        public List<Item_Drop> getLoot()
        {
            return loot;
        }

        public void addToDrops(Item_Drop drop)
        {
            loot.Add(drop);
        }
    }
}
