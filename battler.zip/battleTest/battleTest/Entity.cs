﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Entity
    {
        protected int maxHP;
        protected int currentHP;

        public Entity(int maxHP, int currentHP)
        {
            this.maxHP = maxHP;
            this.currentHP = currentHP;
        }

        public int getMaxHP()
        {
            return maxHP;
        }

        public int getCurrentHP()
        {
            return currentHP;
        }

        public void setCurrentHP(int currentHP)
        {
            this.currentHP = currentHP;
        }
    }
}
