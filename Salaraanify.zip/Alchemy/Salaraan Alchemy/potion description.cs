﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salaraan_Alchemy
{
    public partial class potion_description : Form
    {
        private string[] line = new string[5];

        public potion_description()
        {
            InitializeComponent();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            line[0] = txtName.Text;
            line[1] = txtEffect.Text;
            line[2] = txtDuration.Text;
            line[3] = txtPrepTime.Text;
            line[4] = txtIngredients.Text;

            foreach(string property in line)
            {
                System.IO.File.WriteAllText("Resources\\potionList.csv", property + ",");
            }
        }
    }
}
