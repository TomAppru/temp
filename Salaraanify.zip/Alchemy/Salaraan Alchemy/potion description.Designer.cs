﻿namespace Salaraan_Alchemy
{
    partial class potion_description
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblEffect = new System.Windows.Forms.Label();
            this.lblPrepTime = new System.Windows.Forms.Label();
            this.lblDuration = new System.Windows.Forms.Label();
            this.txtPrepTime = new System.Windows.Forms.TextBox();
            this.txtDuration = new System.Windows.Forms.TextBox();
            this.txtEffect = new System.Windows.Forms.TextBox();
            this.lblIngredients = new System.Windows.Forms.Label();
            this.cmbIngredients = new System.Windows.Forms.ComboBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtIngredients = new System.Windows.Forms.TextBox();
            this.btnDone = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(32, 9);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(38, 13);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(82, 6);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(233, 20);
            this.txtName.TabIndex = 1;
            // 
            // lblEffect
            // 
            this.lblEffect.AutoSize = true;
            this.lblEffect.Location = new System.Drawing.Point(32, 35);
            this.lblEffect.Name = "lblEffect";
            this.lblEffect.Size = new System.Drawing.Size(38, 13);
            this.lblEffect.TabIndex = 2;
            this.lblEffect.Text = "Effect:";
            // 
            // lblPrepTime
            // 
            this.lblPrepTime.AutoSize = true;
            this.lblPrepTime.Location = new System.Drawing.Point(12, 87);
            this.lblPrepTime.Name = "lblPrepTime";
            this.lblPrepTime.Size = new System.Drawing.Size(58, 13);
            this.lblPrepTime.TabIndex = 3;
            this.lblPrepTime.Text = "Prep Time:";
            // 
            // lblDuration
            // 
            this.lblDuration.AutoSize = true;
            this.lblDuration.Location = new System.Drawing.Point(20, 61);
            this.lblDuration.Name = "lblDuration";
            this.lblDuration.Size = new System.Drawing.Size(50, 13);
            this.lblDuration.TabIndex = 4;
            this.lblDuration.Text = "Duration:";
            // 
            // txtPrepTime
            // 
            this.txtPrepTime.Location = new System.Drawing.Point(82, 84);
            this.txtPrepTime.Name = "txtPrepTime";
            this.txtPrepTime.Size = new System.Drawing.Size(233, 20);
            this.txtPrepTime.TabIndex = 5;
            // 
            // txtDuration
            // 
            this.txtDuration.Location = new System.Drawing.Point(82, 58);
            this.txtDuration.Name = "txtDuration";
            this.txtDuration.Size = new System.Drawing.Size(233, 20);
            this.txtDuration.TabIndex = 6;
            // 
            // txtEffect
            // 
            this.txtEffect.Location = new System.Drawing.Point(82, 32);
            this.txtEffect.Name = "txtEffect";
            this.txtEffect.Size = new System.Drawing.Size(233, 20);
            this.txtEffect.TabIndex = 7;
            // 
            // lblIngredients
            // 
            this.lblIngredients.AutoSize = true;
            this.lblIngredients.Location = new System.Drawing.Point(8, 114);
            this.lblIngredients.Name = "lblIngredients";
            this.lblIngredients.Size = new System.Drawing.Size(62, 13);
            this.lblIngredients.TabIndex = 8;
            this.lblIngredients.Text = "Ingredients:";
            // 
            // cmbIngredients
            // 
            this.cmbIngredients.FormattingEnabled = true;
            this.cmbIngredients.Location = new System.Drawing.Point(82, 111);
            this.cmbIngredients.Name = "cmbIngredients";
            this.cmbIngredients.Size = new System.Drawing.Size(154, 21);
            this.cmbIngredients.TabIndex = 9;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(240, 111);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 10;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // txtIngredients
            // 
            this.txtIngredients.Location = new System.Drawing.Point(82, 146);
            this.txtIngredients.Name = "txtIngredients";
            this.txtIngredients.Size = new System.Drawing.Size(154, 20);
            this.txtIngredients.TabIndex = 11;
            // 
            // btnDone
            // 
            this.btnDone.Location = new System.Drawing.Point(240, 144);
            this.btnDone.Name = "btnDone";
            this.btnDone.Size = new System.Drawing.Size(75, 23);
            this.btnDone.TabIndex = 12;
            this.btnDone.Text = "Done";
            this.btnDone.UseVisualStyleBackColor = true;
            this.btnDone.Click += new System.EventHandler(this.btnDone_Click);
            // 
            // potion_description
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 176);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.txtIngredients);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.cmbIngredients);
            this.Controls.Add(this.lblIngredients);
            this.Controls.Add(this.txtEffect);
            this.Controls.Add(this.txtDuration);
            this.Controls.Add(this.txtPrepTime);
            this.Controls.Add(this.lblDuration);
            this.Controls.Add(this.lblPrepTime);
            this.Controls.Add(this.lblEffect);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblName);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "potion_description";
            this.Text = "Add New";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblEffect;
        private System.Windows.Forms.Label lblPrepTime;
        private System.Windows.Forms.Label lblDuration;
        private System.Windows.Forms.TextBox txtPrepTime;
        private System.Windows.Forms.TextBox txtDuration;
        private System.Windows.Forms.TextBox txtEffect;
        private System.Windows.Forms.Label lblIngredients;
        private System.Windows.Forms.ComboBox cmbIngredients;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtIngredients;
        private System.Windows.Forms.Button btnDone;
    }
}