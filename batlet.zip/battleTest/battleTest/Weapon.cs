﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Weapon : Item
    {
        public int minDamage;
        public int maxDamage;
        public int actionPointCost;

        public Weapon(int ID, string itemName, string namePlural, string itemDescription, double cost, int minDamage, int maxDamage, int actionPointCost) :
            base(ID, itemName, namePlural, itemDescription, cost)
        {
            this.minDamage = minDamage;
            this.maxDamage = maxDamage;
            this.actionPointCost = actionPointCost;
        }
    }
}
