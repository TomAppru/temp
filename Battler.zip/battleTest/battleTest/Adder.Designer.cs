﻿namespace battleTest
{
    partial class Adder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblDamage = new System.Windows.Forms.Label();
            this.lblHealth = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtHealth = new System.Windows.Forms.TextBox();
            this.txtMinDamage = new System.Windows.Forms.TextBox();
            this.txtMaxDamage = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(161, 158);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(157, 47);
            this.btnAdd.TabIndex = 19;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblDamage
            // 
            this.lblDamage.AutoSize = true;
            this.lblDamage.Location = new System.Drawing.Point(12, 108);
            this.lblDamage.Name = "lblDamage";
            this.lblDamage.Size = new System.Drawing.Size(126, 20);
            this.lblDamage.TabIndex = 18;
            this.lblDamage.Text = "Damage Range:";
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.Location = new System.Drawing.Point(12, 76);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(108, 20);
            this.lblHealth.TabIndex = 17;
            this.lblHealth.Text = "Health Points:";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(12, 44);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(47, 20);
            this.lblType.TabIndex = 16;
            this.lblType.Text = "Type:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 12);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(55, 20);
            this.lblName.TabIndex = 15;
            this.lblName.Text = "Name:";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(161, 44);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(157, 26);
            this.txtType.TabIndex = 14;
            // 
            // txtHealth
            // 
            this.txtHealth.Location = new System.Drawing.Point(161, 76);
            this.txtHealth.Name = "txtHealth";
            this.txtHealth.Size = new System.Drawing.Size(157, 26);
            this.txtHealth.TabIndex = 13;
            // 
            // txtMinDamage
            // 
            this.txtMinDamage.Location = new System.Drawing.Point(161, 108);
            this.txtMinDamage.Name = "txtMinDamage";
            this.txtMinDamage.Size = new System.Drawing.Size(77, 26);
            this.txtMinDamage.TabIndex = 12;
            // 
            // txtMaxDamage
            // 
            this.txtMaxDamage.Location = new System.Drawing.Point(241, 108);
            this.txtMaxDamage.Name = "txtMaxDamage";
            this.txtMaxDamage.Size = new System.Drawing.Size(77, 26);
            this.txtMaxDamage.TabIndex = 11;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(161, 12);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(157, 26);
            this.txtName.TabIndex = 10;
            // 
            // Adder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 217);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblDamage);
            this.Controls.Add(this.lblHealth);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.txtHealth);
            this.Controls.Add(this.txtMinDamage);
            this.Controls.Add(this.txtMaxDamage);
            this.Controls.Add(this.txtName);
            this.Name = "Adder";
            this.Text = "Add Enemy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblDamage;
        private System.Windows.Forms.Label lblHealth;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtHealth;
        private System.Windows.Forms.TextBox txtMinDamage;
        private System.Windows.Forms.TextBox txtMaxDamage;
        private System.Windows.Forms.TextBox txtName;
    }
}