﻿namespace battleTest
{
    partial class battleWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblItemToUse = new System.Windows.Forms.Label();
            this.lblInventory = new System.Windows.Forms.Label();
            this.dgvInventory = new System.Windows.Forms.DataGridView();
            this.clmItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmItemCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnUseItem = new System.Windows.Forms.Button();
            this.cmbItemToUse = new System.Windows.Forms.ComboBox();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.btnAdder = new System.Windows.Forms.Button();
            this.pbHealth = new System.Windows.Forms.ProgressBar();
            this.lblHPlabel = new System.Windows.Forms.Label();
            this.lblHealth = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            this.SuspendLayout();
            // 
            // lblItemToUse
            // 
            this.lblItemToUse.AutoSize = true;
            this.lblItemToUse.Location = new System.Drawing.Point(393, 472);
            this.lblItemToUse.Name = "lblItemToUse";
            this.lblItemToUse.Size = new System.Drawing.Size(100, 20);
            this.lblItemToUse.TabIndex = 19;
            this.lblItemToUse.Text = "Item To Use:";
            // 
            // lblInventory
            // 
            this.lblInventory.AutoSize = true;
            this.lblInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInventory.Location = new System.Drawing.Point(12, 205);
            this.lblInventory.Name = "lblInventory";
            this.lblInventory.Size = new System.Drawing.Size(115, 29);
            this.lblInventory.TabIndex = 14;
            this.lblInventory.Text = "Inventory:";
            // 
            // dgvInventory
            // 
            this.dgvInventory.AllowUserToAddRows = false;
            this.dgvInventory.AllowUserToDeleteRows = false;
            this.dgvInventory.AllowUserToResizeRows = false;
            this.dgvInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmItemName,
            this.clmItemCount});
            this.dgvInventory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvInventory.Location = new System.Drawing.Point(12, 237);
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.ReadOnly = true;
            this.dgvInventory.RowHeadersVisible = false;
            this.dgvInventory.RowTemplate.Height = 28;
            this.dgvInventory.ShowEditingIcon = false;
            this.dgvInventory.Size = new System.Drawing.Size(374, 354);
            this.dgvInventory.TabIndex = 13;
            // 
            // clmItemName
            // 
            this.clmItemName.HeaderText = "Item";
            this.clmItemName.Name = "clmItemName";
            this.clmItemName.ReadOnly = true;
            this.clmItemName.Width = 200;
            // 
            // clmItemCount
            // 
            this.clmItemCount.HeaderText = "";
            this.clmItemCount.Name = "clmItemCount";
            this.clmItemCount.ReadOnly = true;
            this.clmItemCount.Width = 50;
            // 
            // btnUseItem
            // 
            this.btnUseItem.Location = new System.Drawing.Point(838, 485);
            this.btnUseItem.Name = "btnUseItem";
            this.btnUseItem.Size = new System.Drawing.Size(170, 52);
            this.btnUseItem.TabIndex = 12;
            this.btnUseItem.Text = "Use";
            this.btnUseItem.UseVisualStyleBackColor = true;
            this.btnUseItem.Click += new System.EventHandler(this.btnUseItem_Click);
            // 
            // cmbItemToUse
            // 
            this.cmbItemToUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItemToUse.FormattingEnabled = true;
            this.cmbItemToUse.Location = new System.Drawing.Point(392, 498);
            this.cmbItemToUse.Name = "cmbItemToUse";
            this.cmbItemToUse.Size = new System.Drawing.Size(440, 28);
            this.cmbItemToUse.TabIndex = 11;
            // 
            // rtbOutput
            // 
            this.rtbOutput.BackColor = System.Drawing.SystemColors.Window;
            this.rtbOutput.Location = new System.Drawing.Point(392, 12);
            this.rtbOutput.Name = "rtbOutput";
            this.rtbOutput.ReadOnly = true;
            this.rtbOutput.Size = new System.Drawing.Size(616, 434);
            this.rtbOutput.TabIndex = 10;
            this.rtbOutput.Text = "";
            // 
            // btnAdder
            // 
            this.btnAdder.Location = new System.Drawing.Point(392, 544);
            this.btnAdder.Name = "btnAdder";
            this.btnAdder.Size = new System.Drawing.Size(170, 47);
            this.btnAdder.TabIndex = 20;
            this.btnAdder.Text = "Add Enemy";
            this.btnAdder.UseVisualStyleBackColor = true;
            this.btnAdder.Click += new System.EventHandler(this.btnAdder_Click);
            // 
            // pbHealth
            // 
            this.pbHealth.BackColor = System.Drawing.SystemColors.Desktop;
            this.pbHealth.ForeColor = System.Drawing.Color.ForestGreen;
            this.pbHealth.Location = new System.Drawing.Point(12, 41);
            this.pbHealth.Name = "pbHealth";
            this.pbHealth.Size = new System.Drawing.Size(373, 26);
            this.pbHealth.Step = 1;
            this.pbHealth.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pbHealth.TabIndex = 21;
            // 
            // lblHPlabel
            // 
            this.lblHPlabel.AutoSize = true;
            this.lblHPlabel.Location = new System.Drawing.Point(8, 12);
            this.lblHPlabel.Name = "lblHPlabel";
            this.lblHPlabel.Size = new System.Drawing.Size(35, 20);
            this.lblHPlabel.TabIndex = 22;
            this.lblHPlabel.Text = "HP:";
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.Location = new System.Drawing.Point(8, 70);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(0, 20);
            this.lblHealth.TabIndex = 23;
            // 
            // battleWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1020, 603);
            this.Controls.Add(this.lblHealth);
            this.Controls.Add(this.lblHPlabel);
            this.Controls.Add(this.pbHealth);
            this.Controls.Add(this.btnAdder);
            this.Controls.Add(this.lblItemToUse);
            this.Controls.Add(this.lblInventory);
            this.Controls.Add(this.dgvInventory);
            this.Controls.Add(this.btnUseItem);
            this.Controls.Add(this.cmbItemToUse);
            this.Controls.Add(this.rtbOutput);
            this.Name = "battleWindow";
            this.Text = "Battle-O-Tron";
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblItemToUse;
        private System.Windows.Forms.Label lblInventory;
        private System.Windows.Forms.DataGridView dgvInventory;
        private System.Windows.Forms.Button btnUseItem;
        private System.Windows.Forms.ComboBox cmbItemToUse;
        private System.Windows.Forms.RichTextBox rtbOutput;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmItemCount;
        private System.Windows.Forms.Button btnAdder;
        private System.Windows.Forms.ProgressBar pbHealth;
        private System.Windows.Forms.Label lblHPlabel;
        private System.Windows.Forms.Label lblHealth;
    }
}

