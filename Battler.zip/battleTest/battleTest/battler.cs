﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace battleTest
{
    public partial class battleWindow : Form
    {
        private Player player;
        private List<Inventory_Item> usableItems = new List<Inventory_Item>();
        private Panel[] actionPoints = new Panel[10];
        private Item selectedItem;
        private Random random = new Random();
        private bool gameRunning = false;

        public battleWindow()
        {
            InitializeComponent();

            actionPoints[0] = ap1;
            actionPoints[1] = ap2;
            actionPoints[2] = ap3;
            actionPoints[3] = ap4;
            actionPoints[4] = ap5;
            actionPoints[5] = ap6;
            actionPoints[6] = ap7;
            actionPoints[7] = ap8;
            actionPoints[8] = ap9;
            actionPoints[9] = ap10;
        }

        private void populateComboBox()
        {
            //proc to move inventory items into combobox
            usableItems.Clear();
            cmbItemToUse.Items.Clear();

            foreach (Inventory_Item i in player.inventory)
            {
                if (i.item.ID < 1000)
                {
                    cmbItemToUse.Items.Add(i.item.itemName + " (" + Storage.findWeapon(i.item.ID).actionPointCost + " AP)");
                    usableItems.Add(i);
                }
            }

            try
            {
                cmbItemToUse.SelectedIndex = 0;
                selectedItem = usableItems[0].item;
                btnUseItem.Enabled = true;
            }
            catch (Exception)
            {
                btnUseItem.Enabled = false;
            }
        }

        private void fillInventoryDataGrid(List<Inventory_Item> items)
        {
            List<object> rowToAdd = new List<object>();
            rowToAdd.Add("");
            rowToAdd.Add("");
            rowToAdd.Add("");

            dgvInventory.Rows.Clear();

            foreach (Inventory_Item i in items)
            {
                rowToAdd[0] = i.item.itemName;
                rowToAdd[1] = i.itemAmount;
                rowToAdd[2] = i.item.ID;

                dgvInventory.Rows.Add(rowToAdd.ToArray());
            }

            foreach (DataGridViewRow r in dgvInventory.Rows)
            {
                try
                {
                    Weapon weapon = Storage.findWeapon(int.Parse(r.Cells[2].Value.ToString()));
                    r.Cells[0].ToolTipText = weapon.itemDescription + "\nMin Damage: " + weapon.minDamage + "\nMax Damage: " + weapon.maxDamage;
                }
                catch(Exception)
                {
                    Item item = Storage.findItem(int.Parse(r.Cells[2].Value.ToString()));
                    r.Cells[0].ToolTipText = item.itemDescription;
                }
            }

            populateComboBox();
        }

        private void setHealth(int HP)
        {
            player.currentHP = HP;
            lblHealth.Text = player.currentHP + " / " + player.maxHP;
            pbHealth.Maximum = player.maxHP;
            pbHealth.Value = HP;
        }

        private void setGold(double gold)
        {
            gold = Math.Round(gold, 2);
            player.gold = gold;

            double goldPieces = Math.Truncate(gold);
            double copperPieces = Math.Round((gold - goldPieces), 2) * 100;

            lblGold.Text = goldPieces + "gp " + copperPieces + "cp";
        }

        private void setExperience(int xp)
        {
            player.experiencePoints = xp;
            lblExperience.Text = player.experiencePoints.ToString();
        }
        
        private void setLevel()
        {
            for (int i = 0; i < Player.levelProgression.Length; i++)
            {
                if (player.experiencePoints >= Player.levelProgression[i])
                {
                    player.level = i + 1;
                }
            }

            lblLevel.Text = player.level.ToString();
        }

        private void resetPlayerTraits(int xp, int hp, double gold)
        {
            setExperience(xp);
            setHealth(hp);
            setGold(gold);
            setLevel();

            fillInventoryDataGrid(player.inventory);
        }

        private void btnUseItem_Click(object sender, EventArgs e)
        {
            if (removeActionPoints(0))
            {
                if (selectedItem.isWeapon)
                {
                    Weapon weapon = Storage.findWeapon(selectedItem.ID);
                    int damageOut = random.Next(weapon.minDamage, weapon.maxDamage);

                    if (removeActionPoints(weapon.actionPointCost))
                    {

                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {

        }

        private void btnEndTurn_Click(object sender, EventArgs e)
        {

        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            player = new Player();

            resetPlayerTraits(player.experiencePoints, player.maxHP, player.gold);
        
            btnSave.Visible = true;

            startGame();
        }

        private bool removeActionPoints(int noToRemove)
        {
            for (int i = 9; i >= 0; i--)
            {
                if(actionPoints[i].Visible == true && noToRemove > 0)
                {
                    if (i < noToRemove - 1)
                    {
                        return false;
                    }
                    actionPoints[i].Visible = false;
                    noToRemove--;
                }
            }
            if (actionPoints[0].Visible == false)
            {
                btnUseItem.Enabled = false;
            }

            return true;
        }

        private void startGame()
        {
            rtbOutput.Clear();

            Enemy spawnedEnemy = Storage.enemies[random.Next(Storage.enemies.Count)];

            rtbOutput.AppendText("A " + spawnedEnemy.name + " approaches!");
            rtbOutput.AppendText("\n" + spawnedEnemy.description);

            gameRunning = true;
        }

        private void cmbItemToUse_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedItem = usableItems[cmbItemToUse.SelectedIndex].item;
        }
    }
}
