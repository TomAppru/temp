﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace battleTest
{
    public partial class battleWindow : Form
    {
        public battleWindow()
        {
            InitializeComponent();

            //Placeholder, just inventory for show. Need item class, subclasses for weapons etc.
            dgvInventory.Rows.Add("Rusty Sword", "x1");
            dgvInventory.Rows.Add("Small Healing Potion", "x5");
            dgvInventory.Rows.Add("Beaten Shield", "x1");

            //Again, placeholder. Creates random enemy.
            Enemy enemey = new Enemy();

            //Health placeholder test

            setHealth(20, 20, lblHealth, pbHealth);

            //formatting combobox
            populateComboBox();
            cmbItemToUse.SelectedIndex = 0;
            rtbOutput.AppendText("A wild " + enemey.getName() + " appeared!");
        }

        private void populateComboBox()
        {
            //proc to move inventory items into combobox
            for (int i = 0; i < dgvInventory.RowCount; i++)
            {
                cmbItemToUse.Items.Add(dgvInventory.Rows[i].Cells[0].Value);
            }
        }

        private void setHealth(int HP, int maxHP, Label label, ProgressBar progBar)
        {
            //displays HP
            label.Text = HP + "/" + maxHP;
            progBar.Maximum = maxHP;
            progBar.Value = HP;
        }

        private void btnAdder_Click(object sender, EventArgs e)
        {
            Adder add = new Adder();
            add.Show();
        }

        private void btnUseItem_Click(object sender, EventArgs e)
        {
            setHealth(45, 500, lblHealth, pbHealth);
        }
    }
}
