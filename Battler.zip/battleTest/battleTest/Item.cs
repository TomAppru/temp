﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Item
    {
        public int ID;
        public string itemName;
        public string itemNamePlural;
        public string itemDescription;
        public double cost;
        public bool isWeapon;

        public Item(int ID, string itemName, string itemNamePlural, string itemDescription, double cost)
        {
            this.ID = ID;
            this.itemName = itemName;
            this.itemNamePlural = itemNamePlural;
            this.itemDescription = itemDescription;
            this.cost = cost;
            isWeapon = false;
        }
    }
}
