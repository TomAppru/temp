﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Player : Entity
    {
        private static readonly int[] levelProgression = { 0, 50, 100, 200, 400, 800, 1600, 3200, 6400, 12800, 25600, 51200, 102400 };

        public List<Inventory_Item> inventory;
        public int experiencePoints;
        public int level;
        public double gold;
        public int[] stats = new int[6];
        private int[] defaultStats = { 4, 3, 8, 6, 2, 9 };

        public Player() : 
            base(20, 20)
        {
            experiencePoints = 0;
            level = 0;
            gold = 15.0;
            stats = defaultStats;
            inventory = new List<Inventory_Item>();
            inventory.Add(new Inventory_Item(Storage.findItem(Storage.ITEM_ID_RUSTY_SWORD), 1));
        }

        public Player(int experiencePoints, int level, int[] stats, double gold, int currentHP, int maxHP) : 
            base(maxHP, currentHP)
        {
            this.experiencePoints = experiencePoints;
            this.level = level;
            this.stats = stats;
            this.gold = gold;
            inventory = new List<Inventory_Item>();
        }
    }
}
