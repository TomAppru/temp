﻿namespace battleTest
{
    partial class battleWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblItemToUse = new System.Windows.Forms.Label();
            this.lblInventory = new System.Windows.Forms.Label();
            this.dgvInventory = new System.Windows.Forms.DataGridView();
            this.btnUseItem = new System.Windows.Forms.Button();
            this.cmbItemToUse = new System.Windows.Forms.ComboBox();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.pbHealth = new System.Windows.Forms.ProgressBar();
            this.lblHPlabel = new System.Windows.Forms.Label();
            this.lblHealth = new System.Windows.Forms.Label();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.sfdSavePlayer = new System.Windows.Forms.SaveFileDialog();
            this.btnEndTurn = new System.Windows.Forms.Button();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.clmItemName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmItemCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmItemID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            this.SuspendLayout();
            // 
            // lblItemToUse
            // 
            this.lblItemToUse.AutoSize = true;
            this.lblItemToUse.Location = new System.Drawing.Point(262, 307);
            this.lblItemToUse.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblItemToUse.Name = "lblItemToUse";
            this.lblItemToUse.Size = new System.Drawing.Size(68, 13);
            this.lblItemToUse.TabIndex = 19;
            this.lblItemToUse.Text = "Item To Use:";
            // 
            // lblInventory
            // 
            this.lblInventory.AutoSize = true;
            this.lblInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInventory.Location = new System.Drawing.Point(4, 134);
            this.lblInventory.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblInventory.Name = "lblInventory";
            this.lblInventory.Size = new System.Drawing.Size(78, 20);
            this.lblInventory.TabIndex = 14;
            this.lblInventory.Text = "Inventory:";
            // 
            // dgvInventory
            // 
            this.dgvInventory.AllowUserToAddRows = false;
            this.dgvInventory.AllowUserToDeleteRows = false;
            this.dgvInventory.AllowUserToResizeRows = false;
            this.dgvInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmItemName,
            this.clmItemCount,
            this.clmItemID});
            this.dgvInventory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvInventory.Location = new System.Drawing.Point(8, 159);
            this.dgvInventory.Margin = new System.Windows.Forms.Padding(2);
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.ReadOnly = true;
            this.dgvInventory.RowHeadersVisible = false;
            this.dgvInventory.RowTemplate.Height = 28;
            this.dgvInventory.ShowEditingIcon = false;
            this.dgvInventory.Size = new System.Drawing.Size(249, 225);
            this.dgvInventory.TabIndex = 13;
            // 
            // btnUseItem
            // 
            this.btnUseItem.Location = new System.Drawing.Point(559, 318);
            this.btnUseItem.Margin = new System.Windows.Forms.Padding(2);
            this.btnUseItem.Name = "btnUseItem";
            this.btnUseItem.Size = new System.Drawing.Size(113, 31);
            this.btnUseItem.TabIndex = 12;
            this.btnUseItem.Text = "Use";
            this.btnUseItem.UseVisualStyleBackColor = true;
            this.btnUseItem.Click += new System.EventHandler(this.btnUseItem_Click);
            // 
            // cmbItemToUse
            // 
            this.cmbItemToUse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItemToUse.FormattingEnabled = true;
            this.cmbItemToUse.Location = new System.Drawing.Point(261, 324);
            this.cmbItemToUse.Margin = new System.Windows.Forms.Padding(2);
            this.cmbItemToUse.Name = "cmbItemToUse";
            this.cmbItemToUse.Size = new System.Drawing.Size(295, 21);
            this.cmbItemToUse.TabIndex = 11;
            // 
            // rtbOutput
            // 
            this.rtbOutput.BackColor = System.Drawing.SystemColors.Window;
            this.rtbOutput.Location = new System.Drawing.Point(261, 8);
            this.rtbOutput.Margin = new System.Windows.Forms.Padding(2);
            this.rtbOutput.Name = "rtbOutput";
            this.rtbOutput.ReadOnly = true;
            this.rtbOutput.Size = new System.Drawing.Size(412, 283);
            this.rtbOutput.TabIndex = 10;
            this.rtbOutput.Text = "";
            // 
            // pbHealth
            // 
            this.pbHealth.BackColor = System.Drawing.SystemColors.Desktop;
            this.pbHealth.ForeColor = System.Drawing.Color.ForestGreen;
            this.pbHealth.Location = new System.Drawing.Point(8, 27);
            this.pbHealth.Margin = new System.Windows.Forms.Padding(2);
            this.pbHealth.Name = "pbHealth";
            this.pbHealth.Size = new System.Drawing.Size(249, 17);
            this.pbHealth.Step = 1;
            this.pbHealth.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pbHealth.TabIndex = 21;
            // 
            // lblHPlabel
            // 
            this.lblHPlabel.AutoSize = true;
            this.lblHPlabel.Location = new System.Drawing.Point(5, 8);
            this.lblHPlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHPlabel.Name = "lblHPlabel";
            this.lblHPlabel.Size = new System.Drawing.Size(25, 13);
            this.lblHPlabel.TabIndex = 22;
            this.lblHPlabel.Text = "HP:";
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.Location = new System.Drawing.Point(5, 45);
            this.lblHealth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(0, 13);
            this.lblHealth.TabIndex = 23;
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(185, 86);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(72, 31);
            this.btnLoad.TabIndex = 24;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(185, 123);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(72, 31);
            this.btnSave.TabIndex = 25;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Visible = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEndTurn
            // 
            this.btnEndTurn.Location = new System.Drawing.Point(559, 354);
            this.btnEndTurn.Name = "btnEndTurn";
            this.btnEndTurn.Size = new System.Drawing.Size(113, 31);
            this.btnEndTurn.TabIndex = 26;
            this.btnEndTurn.Text = "End Turn";
            this.btnEndTurn.UseVisualStyleBackColor = true;
            this.btnEndTurn.Click += new System.EventHandler(this.btnEndTurn_Click);
            // 
            // btnNewGame
            // 
            this.btnNewGame.Location = new System.Drawing.Point(185, 49);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(72, 31);
            this.btnNewGame.TabIndex = 27;
            this.btnNewGame.Text = "New Game";
            this.btnNewGame.UseVisualStyleBackColor = true;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // clmItemName
            // 
            this.clmItemName.HeaderText = "Item";
            this.clmItemName.Name = "clmItemName";
            this.clmItemName.ReadOnly = true;
            this.clmItemName.Width = 200;
            // 
            // clmItemCount
            // 
            this.clmItemCount.HeaderText = "";
            this.clmItemCount.Name = "clmItemCount";
            this.clmItemCount.ReadOnly = true;
            this.clmItemCount.Width = 50;
            // 
            // clmItemID
            // 
            this.clmItemID.HeaderText = "";
            this.clmItemID.Name = "clmItemID";
            this.clmItemID.ReadOnly = true;
            this.clmItemID.Visible = false;
            // 
            // battleWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 392);
            this.Controls.Add(this.btnNewGame);
            this.Controls.Add(this.btnEndTurn);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.lblHealth);
            this.Controls.Add(this.lblHPlabel);
            this.Controls.Add(this.pbHealth);
            this.Controls.Add(this.lblItemToUse);
            this.Controls.Add(this.lblInventory);
            this.Controls.Add(this.dgvInventory);
            this.Controls.Add(this.btnUseItem);
            this.Controls.Add(this.cmbItemToUse);
            this.Controls.Add(this.rtbOutput);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "battleWindow";
            this.Text = "Battle-O-Tron";
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblItemToUse;
        private System.Windows.Forms.Label lblInventory;
        private System.Windows.Forms.DataGridView dgvInventory;
        private System.Windows.Forms.Button btnUseItem;
        private System.Windows.Forms.ComboBox cmbItemToUse;
        private System.Windows.Forms.RichTextBox rtbOutput;
        private System.Windows.Forms.ProgressBar pbHealth;
        private System.Windows.Forms.Label lblHPlabel;
        private System.Windows.Forms.Label lblHealth;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.SaveFileDialog sfdSavePlayer;
        private System.Windows.Forms.Button btnEndTurn;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmItemCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmItemID;
    }
}

