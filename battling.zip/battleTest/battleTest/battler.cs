﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace battleTest
{
    public partial class battleWindow : Form
    {
        private Player player;

        public battleWindow()
        {
            InitializeComponent();
        }

        private void populateComboBox()
        {
            //proc to move inventory items into combobox
            for (int i = 0; i < dgvInventory.RowCount; i++)
            {
                cmbItemToUse.Items.Add(dgvInventory.Rows[i].Cells[0].Value);
            }

            cmbItemToUse.SelectedIndex = 0;
        }

        private void fillInventoryDataGrid(List<Inventory_Item> items)
        {
            List<object> rowToAdd = new List<object>();
            rowToAdd.Add("");
            rowToAdd.Add("");
            rowToAdd.Add("");

            foreach (Inventory_Item i in items)
            {
                rowToAdd[0] = i.item.itemName;
                rowToAdd[1] = i.itemAmount;
                rowToAdd[2] = i.item.ID;

                dgvInventory.Rows.Add(rowToAdd.ToArray());
            }

            populateComboBox();
        }

        private void setHealth(int HP, int maxHP, Label label, ProgressBar progBar)
        {
            player.currentHP = HP;
            label.Text = player.currentHP + " / " + player.maxHP;
        }

        private void btnUseItem_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {

        }

        private void btnEndTurn_Click(object sender, EventArgs e)
        {

        }

        private void btnNewGame_Click(object sender, EventArgs e)
        {
            player = new Player();

            fillInventoryDataGrid(player.inventory);

            btnSave.Visible = true;
        }
    }
}
