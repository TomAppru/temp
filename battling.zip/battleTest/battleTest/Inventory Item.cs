﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Inventory_Item
    {
        public Item item;
        public int itemAmount;

        public Inventory_Item(Item item, int itemAmount)
        {
            this.item = item;
            this.itemAmount = itemAmount;
        }
    }
}
