﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Enemy : Entity
    {
        public int ID;
        public string name;
        public string namePlural;
        public string description;
        public Enum type;
        public int minDamage;
        public int maxDamage;
        public List<Item_Drop> loot;
        public int experienceDrop;
        public double maxGoldDrop;

        public Enemy(int ID, string name, string namePlural, string description, int maxHP, int currentHP, Enum type, int minDamage, int maxDamage, int experienceDrop, double maxGoldDrop) : 
            base(maxHP, currentHP)
        {
            this.ID = ID;
            this.name = name;
            this.namePlural = namePlural;
            this.description = description;
            this.type = type;
            this.minDamage = minDamage;
            this.maxDamage = maxDamage;
            loot = new List<Item_Drop>();
            this.experienceDrop = experienceDrop;
            this.maxGoldDrop = maxGoldDrop;
        }
    }
}
