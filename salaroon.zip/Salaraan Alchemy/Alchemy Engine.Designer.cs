﻿namespace Salaraan_Alchemy
{
    partial class alchemyWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlIngredients = new System.Windows.Forms.Panel();
            this.btnRemoveIngredient = new System.Windows.Forms.Button();
            this.btnAddToInventory = new System.Windows.Forms.Button();
            this.txtAddNewIngredient = new System.Windows.Forms.TextBox();
            this.btnAddNewIngredient = new System.Windows.Forms.Button();
            this.lblAddWindow = new System.Windows.Forms.Label();
            this.dgvIngredients = new System.Windows.Forms.DataGridView();
            this.clmIngredientToAdd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtAddIngredientSearch = new System.Windows.Forms.TextBox();
            this.pnlInventory = new System.Windows.Forms.Panel();
            this.btnRemoveFromInventory = new System.Windows.Forms.Button();
            this.txtInventorySearch = new System.Windows.Forms.TextBox();
            this.dgvInventory = new System.Windows.Forms.DataGridView();
            this.clmIngredients = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblInventory = new System.Windows.Forms.Label();
            this.pnlCraftables = new System.Windows.Forms.Panel();
            this.btnShowDescription = new System.Windows.Forms.Button();
            this.btnToggleCraftableMode = new System.Windows.Forms.Button();
            this.btnAddCraftable = new System.Windows.Forms.Button();
            this.txtCraftablesSearch = new System.Windows.Forms.TextBox();
            this.dgvCraftables = new System.Windows.Forms.DataGridView();
            this.clmCraftableName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmCraftableIngredients = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmSearched = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCraftables = new System.Windows.Forms.Label();
            this.pnlIngredients.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIngredients)).BeginInit();
            this.pnlInventory.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            this.pnlCraftables.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCraftables)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlIngredients
            // 
            this.pnlIngredients.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlIngredients.Controls.Add(this.btnRemoveIngredient);
            this.pnlIngredients.Controls.Add(this.btnAddToInventory);
            this.pnlIngredients.Controls.Add(this.txtAddNewIngredient);
            this.pnlIngredients.Controls.Add(this.btnAddNewIngredient);
            this.pnlIngredients.Controls.Add(this.lblAddWindow);
            this.pnlIngredients.Controls.Add(this.dgvIngredients);
            this.pnlIngredients.Controls.Add(this.txtAddIngredientSearch);
            this.pnlIngredients.Location = new System.Drawing.Point(18, 357);
            this.pnlIngredients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlIngredients.Name = "pnlIngredients";
            this.pnlIngredients.Size = new System.Drawing.Size(500, 405);
            this.pnlIngredients.TabIndex = 1;
            // 
            // btnRemoveIngredient
            // 
            this.btnRemoveIngredient.Location = new System.Drawing.Point(288, 305);
            this.btnRemoveIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRemoveIngredient.Name = "btnRemoveIngredient";
            this.btnRemoveIngredient.Size = new System.Drawing.Size(204, 43);
            this.btnRemoveIngredient.TabIndex = 7;
            this.btnRemoveIngredient.Text = "Remove From List";
            this.btnRemoveIngredient.UseVisualStyleBackColor = true;
            this.btnRemoveIngredient.Click += new System.EventHandler(this.btnRemoveIngredient_Click);
            // 
            // btnAddToInventory
            // 
            this.btnAddToInventory.Location = new System.Drawing.Point(4, 305);
            this.btnAddToInventory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddToInventory.Name = "btnAddToInventory";
            this.btnAddToInventory.Size = new System.Drawing.Size(204, 43);
            this.btnAddToInventory.TabIndex = 6;
            this.btnAddToInventory.Text = "Add To Inventory";
            this.btnAddToInventory.UseVisualStyleBackColor = true;
            this.btnAddToInventory.Click += new System.EventHandler(this.btnAddToInventory_Click);
            // 
            // txtAddNewIngredient
            // 
            this.txtAddNewIngredient.Location = new System.Drawing.Point(4, 363);
            this.txtAddNewIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAddNewIngredient.Name = "txtAddNewIngredient";
            this.txtAddNewIngredient.Size = new System.Drawing.Size(272, 26);
            this.txtAddNewIngredient.TabIndex = 4;
            this.txtAddNewIngredient.Enter += new System.EventHandler(this.txtAddNewIngredient_Enter);
            this.txtAddNewIngredient.Leave += new System.EventHandler(this.txtAddNewIngredient_Leave);
            // 
            // btnAddNewIngredient
            // 
            this.btnAddNewIngredient.Location = new System.Drawing.Point(288, 355);
            this.btnAddNewIngredient.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddNewIngredient.Name = "btnAddNewIngredient";
            this.btnAddNewIngredient.Size = new System.Drawing.Size(204, 43);
            this.btnAddNewIngredient.TabIndex = 3;
            this.btnAddNewIngredient.Text = "Add New Ingredient";
            this.btnAddNewIngredient.UseVisualStyleBackColor = true;
            this.btnAddNewIngredient.Click += new System.EventHandler(this.btnAddNewIngredient_Click);
            // 
            // lblAddWindow
            // 
            this.lblAddWindow.AutoSize = true;
            this.lblAddWindow.Font = new System.Drawing.Font("Palatino Linotype", 13.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddWindow.Location = new System.Drawing.Point(4, 3);
            this.lblAddWindow.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddWindow.Name = "lblAddWindow";
            this.lblAddWindow.Size = new System.Drawing.Size(487, 37);
            this.lblAddWindow.TabIndex = 2;
            this.lblAddWindow.Text = "ADD INGREDIENT TO INVENTORY";
            // 
            // dgvIngredients
            // 
            this.dgvIngredients.AllowUserToAddRows = false;
            this.dgvIngredients.AllowUserToDeleteRows = false;
            this.dgvIngredients.AllowUserToResizeRows = false;
            this.dgvIngredients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIngredients.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmIngredientToAdd});
            this.dgvIngredients.Location = new System.Drawing.Point(4, 88);
            this.dgvIngredients.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvIngredients.MultiSelect = false;
            this.dgvIngredients.Name = "dgvIngredients";
            this.dgvIngredients.ReadOnly = true;
            this.dgvIngredients.RowHeadersVisible = false;
            this.dgvIngredients.Size = new System.Drawing.Size(488, 208);
            this.dgvIngredients.TabIndex = 1;
            // 
            // clmIngredientToAdd
            // 
            this.clmIngredientToAdd.HeaderText = "Ingredient";
            this.clmIngredientToAdd.Name = "clmIngredientToAdd";
            this.clmIngredientToAdd.ReadOnly = true;
            this.clmIngredientToAdd.Width = 322;
            // 
            // txtAddIngredientSearch
            // 
            this.txtAddIngredientSearch.Location = new System.Drawing.Point(4, 48);
            this.txtAddIngredientSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAddIngredientSearch.Name = "txtAddIngredientSearch";
            this.txtAddIngredientSearch.Size = new System.Drawing.Size(486, 26);
            this.txtAddIngredientSearch.TabIndex = 0;
            this.txtAddIngredientSearch.TextChanged += new System.EventHandler(this.txtAddIngredientSearch_TextChanged);
            this.txtAddIngredientSearch.Enter += new System.EventHandler(this.txtAddIngredientSearch_Enter);
            this.txtAddIngredientSearch.Leave += new System.EventHandler(this.txtAddIngredientSearch_Leave);
            // 
            // pnlInventory
            // 
            this.pnlInventory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInventory.Controls.Add(this.btnRemoveFromInventory);
            this.pnlInventory.Controls.Add(this.txtInventorySearch);
            this.pnlInventory.Controls.Add(this.dgvInventory);
            this.pnlInventory.Controls.Add(this.lblInventory);
            this.pnlInventory.Location = new System.Drawing.Point(18, 18);
            this.pnlInventory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlInventory.Name = "pnlInventory";
            this.pnlInventory.Size = new System.Drawing.Size(500, 328);
            this.pnlInventory.TabIndex = 3;
            // 
            // btnRemoveFromInventory
            // 
            this.btnRemoveFromInventory.Location = new System.Drawing.Point(288, 5);
            this.btnRemoveFromInventory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRemoveFromInventory.Name = "btnRemoveFromInventory";
            this.btnRemoveFromInventory.Size = new System.Drawing.Size(204, 43);
            this.btnRemoveFromInventory.TabIndex = 8;
            this.btnRemoveFromInventory.Text = "Remove Selected Item";
            this.btnRemoveFromInventory.UseVisualStyleBackColor = true;
            this.btnRemoveFromInventory.Click += new System.EventHandler(this.btnRemoveFromInventory_Click);
            // 
            // txtInventorySearch
            // 
            this.txtInventorySearch.Location = new System.Drawing.Point(4, 57);
            this.txtInventorySearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtInventorySearch.Name = "txtInventorySearch";
            this.txtInventorySearch.Size = new System.Drawing.Size(486, 26);
            this.txtInventorySearch.TabIndex = 4;
            this.txtInventorySearch.TextChanged += new System.EventHandler(this.txtInventorySearch_TextChanged);
            this.txtInventorySearch.Enter += new System.EventHandler(this.txtInventorySearch_Enter);
            this.txtInventorySearch.Leave += new System.EventHandler(this.txtInventorySearch_Leave);
            // 
            // dgvInventory
            // 
            this.dgvInventory.AllowUserToAddRows = false;
            this.dgvInventory.AllowUserToDeleteRows = false;
            this.dgvInventory.AllowUserToResizeRows = false;
            this.dgvInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmIngredients,
            this.clmAmount});
            this.dgvInventory.Location = new System.Drawing.Point(4, 97);
            this.dgvInventory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvInventory.MultiSelect = false;
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.ReadOnly = true;
            this.dgvInventory.RowHeadersVisible = false;
            this.dgvInventory.Size = new System.Drawing.Size(488, 225);
            this.dgvInventory.TabIndex = 4;
            // 
            // clmIngredients
            // 
            this.clmIngredients.HeaderText = "Ingredient";
            this.clmIngredients.Name = "clmIngredients";
            this.clmIngredients.ReadOnly = true;
            this.clmIngredients.Width = 272;
            // 
            // clmAmount
            // 
            this.clmAmount.HeaderText = "";
            this.clmAmount.Name = "clmAmount";
            this.clmAmount.ReadOnly = true;
            this.clmAmount.Width = 50;
            // 
            // lblInventory
            // 
            this.lblInventory.AutoSize = true;
            this.lblInventory.Font = new System.Drawing.Font("Palatino Linotype", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInventory.Location = new System.Drawing.Point(4, 0);
            this.lblInventory.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInventory.Name = "lblInventory";
            this.lblInventory.Size = new System.Drawing.Size(205, 41);
            this.lblInventory.TabIndex = 3;
            this.lblInventory.Text = "INVENTORY";
            // 
            // pnlCraftables
            // 
            this.pnlCraftables.AutoSize = true;
            this.pnlCraftables.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlCraftables.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCraftables.Controls.Add(this.btnShowDescription);
            this.pnlCraftables.Controls.Add(this.btnToggleCraftableMode);
            this.pnlCraftables.Controls.Add(this.btnAddCraftable);
            this.pnlCraftables.Controls.Add(this.txtCraftablesSearch);
            this.pnlCraftables.Controls.Add(this.dgvCraftables);
            this.pnlCraftables.Controls.Add(this.lblCraftables);
            this.pnlCraftables.Location = new System.Drawing.Point(530, 18);
            this.pnlCraftables.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pnlCraftables.Name = "pnlCraftables";
            this.pnlCraftables.Size = new System.Drawing.Size(580, 744);
            this.pnlCraftables.TabIndex = 4;
            // 
            // btnShowDescription
            // 
            this.btnShowDescription.AutoSize = true;
            this.btnShowDescription.Location = new System.Drawing.Point(178, 680);
            this.btnShowDescription.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnShowDescription.Name = "btnShowDescription";
            this.btnShowDescription.Size = new System.Drawing.Size(220, 57);
            this.btnShowDescription.TabIndex = 7;
            this.btnShowDescription.Text = "Show Item Description";
            this.btnShowDescription.UseVisualStyleBackColor = true;
            this.btnShowDescription.Click += new System.EventHandler(this.btnShowDescription_Click);
            // 
            // btnToggleCraftableMode
            // 
            this.btnToggleCraftableMode.AutoSize = true;
            this.btnToggleCraftableMode.Location = new System.Drawing.Point(4, 680);
            this.btnToggleCraftableMode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnToggleCraftableMode.Name = "btnToggleCraftableMode";
            this.btnToggleCraftableMode.Size = new System.Drawing.Size(166, 57);
            this.btnToggleCraftableMode.TabIndex = 6;
            this.btnToggleCraftableMode.Text = "Show Available";
            this.btnToggleCraftableMode.UseVisualStyleBackColor = true;
            this.btnToggleCraftableMode.Click += new System.EventHandler(this.btnToggleCraftableMode_Click);
            // 
            // btnAddCraftable
            // 
            this.btnAddCraftable.AutoSize = true;
            this.btnAddCraftable.Location = new System.Drawing.Point(406, 680);
            this.btnAddCraftable.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAddCraftable.Name = "btnAddCraftable";
            this.btnAddCraftable.Size = new System.Drawing.Size(168, 57);
            this.btnAddCraftable.TabIndex = 5;
            this.btnAddCraftable.Text = "Add New Craftable";
            this.btnAddCraftable.UseVisualStyleBackColor = true;
            this.btnAddCraftable.Click += new System.EventHandler(this.btnAddCraftable_Click);
            // 
            // txtCraftablesSearch
            // 
            this.txtCraftablesSearch.Location = new System.Drawing.Point(4, 45);
            this.txtCraftablesSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCraftablesSearch.Name = "txtCraftablesSearch";
            this.txtCraftablesSearch.Size = new System.Drawing.Size(556, 26);
            this.txtCraftablesSearch.TabIndex = 5;
            this.txtCraftablesSearch.TextChanged += new System.EventHandler(this.txtCraftablesSearch_TextChanged);
            this.txtCraftablesSearch.Enter += new System.EventHandler(this.txtCraftablesSearch_Enter);
            this.txtCraftablesSearch.Leave += new System.EventHandler(this.txtCraftablesSearch_Leave);
            // 
            // dgvCraftables
            // 
            this.dgvCraftables.AllowUserToAddRows = false;
            this.dgvCraftables.AllowUserToDeleteRows = false;
            this.dgvCraftables.AllowUserToResizeRows = false;
            this.dgvCraftables.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCraftables.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clmCraftableName,
            this.clmCraftableIngredients,
            this.clmSearched});
            this.dgvCraftables.Location = new System.Drawing.Point(11, 84);
            this.dgvCraftables.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgvCraftables.MultiSelect = false;
            this.dgvCraftables.Name = "dgvCraftables";
            this.dgvCraftables.ReadOnly = true;
            this.dgvCraftables.RowHeadersVisible = false;
            this.dgvCraftables.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCraftables.RowTemplate.Height = 45;
            this.dgvCraftables.RowTemplate.ReadOnly = true;
            this.dgvCraftables.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCraftables.Size = new System.Drawing.Size(558, 586);
            this.dgvCraftables.TabIndex = 5;
            this.dgvCraftables.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvCraftables_CellFormatting);
            // 
            // clmCraftableName
            // 
            this.clmCraftableName.HeaderText = "Name";
            this.clmCraftableName.Name = "clmCraftableName";
            this.clmCraftableName.ReadOnly = true;
            this.clmCraftableName.Width = 150;
            // 
            // clmCraftableIngredients
            // 
            this.clmCraftableIngredients.HeaderText = "Ingredients";
            this.clmCraftableIngredients.Name = "clmCraftableIngredients";
            this.clmCraftableIngredients.ReadOnly = true;
            this.clmCraftableIngredients.Width = 219;
            // 
            // clmSearched
            // 
            this.clmSearched.HeaderText = "Searched";
            this.clmSearched.Name = "clmSearched";
            this.clmSearched.ReadOnly = true;
            this.clmSearched.Visible = false;
            // 
            // lblCraftables
            // 
            this.lblCraftables.AutoSize = true;
            this.lblCraftables.Font = new System.Drawing.Font("Palatino Linotype", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCraftables.Location = new System.Drawing.Point(4, 0);
            this.lblCraftables.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCraftables.Name = "lblCraftables";
            this.lblCraftables.Size = new System.Drawing.Size(216, 41);
            this.lblCraftables.TabIndex = 4;
            this.lblCraftables.Text = "CRAFTABLES";
            // 
            // alchemyWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1192, 836);
            this.Controls.Add(this.pnlCraftables);
            this.Controls.Add(this.pnlInventory);
            this.Controls.Add(this.pnlIngredients);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "alchemyWindow";
            this.Text = "The Alembic";
            this.pnlIngredients.ResumeLayout(false);
            this.pnlIngredients.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIngredients)).EndInit();
            this.pnlInventory.ResumeLayout(false);
            this.pnlInventory.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            this.pnlCraftables.ResumeLayout(false);
            this.pnlCraftables.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCraftables)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlIngredients;
        private System.Windows.Forms.TextBox txtAddNewIngredient;
        private System.Windows.Forms.Button btnAddNewIngredient;
        private System.Windows.Forms.Label lblAddWindow;
        private System.Windows.Forms.DataGridView dgvIngredients;
        private System.Windows.Forms.TextBox txtAddIngredientSearch;
        private System.Windows.Forms.Panel pnlInventory;
        private System.Windows.Forms.TextBox txtInventorySearch;
        private System.Windows.Forms.DataGridView dgvInventory;
        private System.Windows.Forms.Label lblInventory;
        private System.Windows.Forms.Panel pnlCraftables;
        private System.Windows.Forms.Button btnAddCraftable;
        private System.Windows.Forms.TextBox txtCraftablesSearch;
        private System.Windows.Forms.DataGridView dgvCraftables;
        private System.Windows.Forms.Label lblCraftables;
        private System.Windows.Forms.Button btnRemoveIngredient;
        private System.Windows.Forms.Button btnAddToInventory;
        private System.Windows.Forms.Button btnToggleCraftableMode;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmIngredientToAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmIngredients;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmAmount;
        private System.Windows.Forms.Button btnShowDescription;
        private System.Windows.Forms.Button btnRemoveFromInventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmCraftableName;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmCraftableIngredients;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmSearched;
    }
}

