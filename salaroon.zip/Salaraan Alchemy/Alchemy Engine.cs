﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salaraan_Alchemy
{
    public partial class alchemyWindow : Form
    {
        private bool generalBoolean;

        public alchemyWindow()
        {
            InitializeComponent();
            formLoadsTextBoxes();
            dataGridPopulate(dgvCraftables, 2, "potionList.csv");
            dataGridPopulate(dgvIngredients, 1, "allIngredients.txt");
        }

        private void dataGridPopulate(DataGridView dgv, int colCount, string fileName)
        {
            string[] linesFromFile = System.IO.File.ReadAllLines("Resources\\" + fileName);
            string[][] cellsFromFile = new string[linesFromFile.Length][];
            string[] lineToAdd = new string[2];
            char[] delimeters = { ',' };

            dgv.Rows.Clear();

            if (colCount == 2)
            {
                for (int i = 0; i < cellsFromFile.Length; i++)
                {
                    cellsFromFile[i] = linesFromFile[i].Split(delimeters, StringSplitOptions.RemoveEmptyEntries);
                    lineToAdd[0] = cellsFromFile[i][0]; lineToAdd[1] = cellsFromFile[i][4];
                    dgv.Rows.Add(lineToAdd);
                    dgv.Rows[i].Cells[2].Value = "true";
                }
            }

            if (colCount == 1)
            {
                for (int i = 0; i < linesFromFile.Length; i++)
                {
                    dgv.Rows.Add(linesFromFile[i]);
                }
            }
        }

        private void btnToggleCraftableMode_Click(object sender, EventArgs e)
        {
            switch (btnToggleCraftableMode.Text)
            {
                case "Show All":
                    btnToggleCraftableMode.Text = "Show Available";
                    showAll();
                    break;
                case "Show Available":
                    btnToggleCraftableMode.Text = "Show All";
                    showAvailable();
                    break;
            }
        }

        private void showAll()
        {
            foreach(DataGridViewRow row in dgvCraftables.Rows)
            {
                if(row.Visible == false && row.Cells[2].Value.ToString() == "true")
                {
                    row.Visible = true;
                }
            }
        }

        private void showAvailable()
        {
            string[] ingredientsRequired;
            string[] splitters = { " + " };
            int ingredientsGot = 0;

            foreach (DataGridViewRow craftableRow in dgvCraftables.Rows)
            {
                ingredientsRequired = craftableRow.Cells[1].Value.ToString().Split(splitters, StringSplitOptions.RemoveEmptyEntries);
                ingredientsGot = 0;

                foreach (string ingredient in ingredientsRequired)
                {
                    foreach (DataGridViewRow inventoryRow in dgvInventory.Rows)
                    {
                        if (inventoryRow.Cells[0].Value.ToString() == ingredient)
                        {
                            ingredientsGot++;
                        }
                    }
                }

                if (ingredientsGot == ingredientsRequired.Count())
                {
                    craftableRow.Visible = true;
                }

                else
                {
                    craftableRow.Visible = false;
                }
            }
        }

        private void tableSearch(TextBox txt, DataGridView dgv, string watermark)
        {
            dgv.ClearSelection();

            if (txt.Text != watermark)
            {
                for (int i = 0; i < dgv.Rows.Count; i++)
                {
                    if (dgv.Rows[i].Cells[0].Value.ToString().ToLower().Contains(txt.Text.ToLower()))
                    {
                        dgv.Rows[i].Visible = true;

                        try
                        {
                            dgv.Rows[i].Cells[2].Value = "true";
                        }
                        catch
                        {
                            //lol
                        }
                    }

                    else
                    {
                        dgv.Rows[i].Visible = false;

                        try
                        {
                            dgv.Rows[i].Cells[2].Value = "false";
                        }
                        catch
                        {
                            //lol
                        }
                    }
                }
            }

            else
            {
                for (int i = 0; i < dgv.Rows.Count; i++)
                {
                    dgv.Rows[i].Visible = true;
                }
            }
        }

        #region watermark

        private void formLoadsTextBoxes()
        {
            leaveTextBox(txtInventorySearch, "Search Inventory");
            leaveTextBox(txtAddIngredientSearch, "Search Available Ingredients");
            leaveTextBox(txtCraftablesSearch, "Search Craftables");
            leaveTextBox(txtAddNewIngredient, "Name New Ingredient");
        }

        private void txtInventorySearch_Leave(object sender, EventArgs e)
        {
            leaveTextBox(txtInventorySearch, "Search Inventory");
        }

        private void txtInventorySearch_Enter(object sender, EventArgs e)
        {
            enterTextBox(txtInventorySearch, "Search Inventory");
        }

        private void txtAddIngredientSearch_Leave(object sender, EventArgs e)
        {
            leaveTextBox(txtAddIngredientSearch, "Search Available Ingredients");
        }

        private void txtAddIngredientSearch_Enter(object sender, EventArgs e)
        {
            enterTextBox(txtAddIngredientSearch, "Search Available Ingredients");
        }

        private void txtCraftablesSearch_Enter(object sender, EventArgs e)
        {
            enterTextBox(txtCraftablesSearch, "Search Craftables");
        }

        private void txtCraftablesSearch_Leave(object sender, EventArgs e)
        {
            leaveTextBox(txtCraftablesSearch, "Search Craftables");
        }

        private void txtAddNewIngredient_Leave(object sender, EventArgs e)
        {
            leaveTextBox(txtAddNewIngredient, "Name New Ingredient");
        }

        private void txtAddNewIngredient_Enter(object sender, EventArgs e)
        {
            enterTextBox(txtAddNewIngredient, "Name New Ingredient");
        }

        private void enterTextBox(TextBox txt, string watermark)
        {
            if (txt.Text == watermark && txt.ForeColor == SystemColors.GrayText)
            {
                txt.Text = "";
                txt.ForeColor = SystemColors.WindowText;
            }
        }

        private void leaveTextBox(TextBox txt, string watermark)
        {
            if (string.IsNullOrWhiteSpace(txt.Text))
            {
                txt.Text = watermark;
                txt.ForeColor = SystemColors.GrayText;
            }
        }


        #endregion

        private void txtCraftablesSearch_TextChanged(object sender, EventArgs e)
        {
            tableSearch(txtCraftablesSearch, dgvCraftables, "Search Craftables");
            
        }

        private void txtAddIngredientSearch_TextChanged(object sender, EventArgs e)
        {
            tableSearch(txtAddIngredientSearch, dgvIngredients, "Search Available Ingredients");
        }

        private void txtInventorySearch_TextChanged(object sender, EventArgs e)
        {
            tableSearch(txtInventorySearch, dgvInventory, "Search Inventory");
        }

        private void btnAddToInventory_Click(object sender, EventArgs e)
        {
            generalBoolean = false;
            try
            {
                if (dgvInventory.Rows.Count > 0)
                {
                    foreach (DataGridViewRow i in dgvInventory.Rows)
                    {
                        if (i.Cells[0].Value.ToString().Contains(dgvIngredients.Rows[dgvIngredients.CurrentCell.RowIndex].Cells[0].Value.ToString()))
                        {
                            generalBoolean = true;
                        }
                    }

                    if (generalBoolean == false)
                    {
                        dgvInventory.Rows.Add(dgvIngredients.Rows[dgvIngredients.CurrentCell.RowIndex].Cells[0].Value);
                        dgvInventory.Rows[dgvInventory.Rows.Count - 1].Cells[1].Value = 1;
                    }

                    else
                    {
                        foreach (DataGridViewRow i in dgvInventory.Rows)
                        {
                            if (i.Cells[0].Value.ToString().Contains(dgvIngredients.Rows[dgvIngredients.CurrentCell.RowIndex].Cells[0].Value.ToString()))
                            {
                                i.Cells[1].Value = int.Parse(i.Cells[1].Value.ToString()) + 1;
                            }
                        }
                    }
                }

                else
                {
                    dgvInventory.Rows.Add(dgvIngredients.Rows[dgvIngredients.CurrentCell.RowIndex].Cells[0].Value);
                    dgvInventory.Rows[dgvInventory.Rows.Count - 1].Cells[1].Value = 1;
                }
            }
            catch(Exception)
            {
                //Nothing to see here
            }
        }

        private void btnRemoveIngredient_Click(object sender, EventArgs e)
        {
            List<string> ingredients = System.IO.File.ReadAllLines("Resources\\allIngredients.txt").ToList();
            ingredients.Remove(dgvIngredients.CurrentCell.Value.ToString());
            System.IO.File.WriteAllLines("Resources\\allIngredients.txt", ingredients.ToArray());
            dataGridPopulate(dgvIngredients, 1, "allIngredients.txt");
        }

        private void btnAddNewIngredient_Click(object sender, EventArgs e)
        {
            System.IO.File.AppendAllText("Resources\\allIngredients.txt", txtAddNewIngredient.Text +  Environment.NewLine);
            dataGridPopulate(dgvIngredients, 1, "allIngredients.txt");
        }

        private void btnRemoveFromInventory_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.Parse(dgvInventory.Rows[dgvInventory.CurrentCell.RowIndex].Cells[1].Value.ToString()) > 1)
                {
                    dgvInventory.Rows[dgvInventory.CurrentCell.RowIndex].Cells[1].Value = int.Parse(dgvInventory.Rows[dgvInventory.CurrentCell.RowIndex].Cells[1].Value.ToString()) - 1;
                }

                else
                {
                    dgvInventory.Rows.RemoveAt(dgvInventory.CurrentCell.RowIndex);
                }
            }

            catch (Exception)
            {
                //I want nothing to happen
            }
        }

        private void btnAddCraftable_Click(object sender, EventArgs e)
        {

        }

        private void btnShowDescription_Click(object sender, EventArgs e)
        {
            
        }

        private void dgvCraftables_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

        }
    }
}
