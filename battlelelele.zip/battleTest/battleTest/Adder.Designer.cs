﻿namespace battleTest
{
    partial class Adder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblDamage = new System.Windows.Forms.Label();
            this.lblHealth = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtHealth = new System.Windows.Forms.TextBox();
            this.txtMinDamage = new System.Windows.Forms.TextBox();
            this.txtMaxDamage = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(107, 99);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(106, 31);
            this.btnAdd.TabIndex = 19;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblDamage
            // 
            this.lblDamage.AutoSize = true;
            this.lblDamage.Location = new System.Drawing.Point(8, 71);
            this.lblDamage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDamage.Name = "lblDamage";
            this.lblDamage.Size = new System.Drawing.Size(85, 13);
            this.lblDamage.TabIndex = 18;
            this.lblDamage.Text = "Damage Range:";
            // 
            // lblHealth
            // 
            this.lblHealth.AutoSize = true;
            this.lblHealth.Location = new System.Drawing.Point(8, 50);
            this.lblHealth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHealth.Name = "lblHealth";
            this.lblHealth.Size = new System.Drawing.Size(73, 13);
            this.lblHealth.TabIndex = 17;
            this.lblHealth.Text = "Health Points:";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(8, 29);
            this.lblType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(34, 13);
            this.lblType.TabIndex = 16;
            this.lblType.Text = "Type:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(8, 8);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(38, 13);
            this.lblName.TabIndex = 15;
            this.lblName.Text = "Name:";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(107, 29);
            this.txtType.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(106, 20);
            this.txtType.TabIndex = 14;
            // 
            // txtHealth
            // 
            this.txtHealth.Location = new System.Drawing.Point(107, 50);
            this.txtHealth.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtHealth.Name = "txtHealth";
            this.txtHealth.Size = new System.Drawing.Size(106, 20);
            this.txtHealth.TabIndex = 13;
            // 
            // txtMinDamage
            // 
            this.txtMinDamage.Location = new System.Drawing.Point(107, 71);
            this.txtMinDamage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMinDamage.Name = "txtMinDamage";
            this.txtMinDamage.Size = new System.Drawing.Size(52, 20);
            this.txtMinDamage.TabIndex = 12;
            // 
            // txtMaxDamage
            // 
            this.txtMaxDamage.Location = new System.Drawing.Point(161, 71);
            this.txtMaxDamage.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtMaxDamage.Name = "txtMaxDamage";
            this.txtMaxDamage.Size = new System.Drawing.Size(52, 20);
            this.txtMaxDamage.TabIndex = 11;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(107, 8);
            this.txtName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(106, 20);
            this.txtName.TabIndex = 10;
            // 
            // Adder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(221, 141);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblDamage);
            this.Controls.Add(this.lblHealth);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.txtHealth);
            this.Controls.Add(this.txtMinDamage);
            this.Controls.Add(this.txtMaxDamage);
            this.Controls.Add(this.txtName);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Adder";
            this.Text = "Add Enemy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblDamage;
        private System.Windows.Forms.Label lblHealth;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtHealth;
        private System.Windows.Forms.TextBox txtMinDamage;
        private System.Windows.Forms.TextBox txtMaxDamage;
        private System.Windows.Forms.TextBox txtName;
    }
}