﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace battleTest
{
    public partial class battleWindow : Form
    {

        public battleWindow()
        {
            InitializeComponent();

            //formatting combobox
            populateComboBox();
            //cmbItemToUse.SelectedIndex = 0;
        }

        private void populateComboBox()
        {
            //proc to move inventory items into combobox
            for (int i = 0; i < dgvInventory.RowCount; i++)
            {
                cmbItemToUse.Items.Add(dgvInventory.Rows[i].Cells[0].Value);
            }
        }

        private void setHealth(int HP, int maxHP, Label label, ProgressBar progBar)
        {
            //displays HP
            label.Text = HP + "/" + maxHP;
            progBar.Maximum = maxHP;
            progBar.Value = HP;
        }

        private void btnAdder_Click(object sender, EventArgs e)
        {
            Adder add = new Adder();
            add.Show();
        }

        private void btnUseItem_Click(object sender, EventArgs e)
        {
            setHealth(34, 50, lblHealth, pbHealth);
        }
    }
}
